# Burger Barn
A simple, highly gernalized program for "purchaseing" burgers
does not need a readme
and yet, here we are... so why?
Hmm, what if we make a ***List of all the Reqrirments!***
# Reqrirments/ modification
just the requriments of the program, or the edits to make to said program
## What modification
1. Minimize changes to only what is necessary to integrate your codeMake the following adjustments to your partner's program. You are allowed to modify your partner's code, but only enough to implement your own features.
2. Change the "Apply Coupon" button to a "Combo Box."
3. The combo box should list several different percentages (example: 20%, 40%, 60%).
4. Selecting an option applies that discount to the Total.
5. Remove the Sides category from the menu.
6. Modify the List Box to sort items (from highest to lowest).
7. Your code must be thoroughly commented, to the point where another Crew member can understand what your program does without looking at the code.
8. If there are any errors in the program, whether from your code or your partner's, fix them. Add comments stating what the error was, and how you fixed it. 

# BASE INFO
some information that doesn't really change, so shall stay
## Cost of Items
### Burgers
1. Plain burger: $4.99
1. Cheeseburger: $5.99
1. Veggie burger: $6.49
1. Bacon Burger: $7.99
### Sides
1. Fries: $0.50
1. Tater tots: $0.75
1. Onion rings: $0.99
1. Chips: $0.99
### Drinks
1. Cola: $1.29
1. Tea: $1.19
1. Fruit Punch: $1.09
1. Water: $0.99
### Sandwiches
1. Chicken Sandwich: $3.99
1. Turkey Club: $5.49
1. Italian Sub: $7.49
1. BLT: $3.49
## Combos
### Number 1 combo Combo: $5.99
1. Plain Burger
1. Fries
1. Cola
### Number 2 Combo: $6.49
1. Cheese Burger
1. Tea
1. Onion Rings
### Number 3 Combo: $8.99
1. Bacon Burger
1. Chips
1. Cola
## NOTES
1. integrated by useing tags on the radio buttons.
1. few alternative ideas might be used, such as utilizing the contents of the name itself 
1. Note: combos have not been integrated
